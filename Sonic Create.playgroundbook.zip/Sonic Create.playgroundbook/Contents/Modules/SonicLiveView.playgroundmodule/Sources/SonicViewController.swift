//
//  SonicLiveViewController.swift
//
//  Copyright © 2016-2018 Apple Inc. All rights reserved.
//

import SPCCore
import SPCLiveView
import SPCScene
import SPCAudio
import SPCAccessibility
import SPCLearningTrails
import UIKit

public class SonicLiveViewController: LiveViewController {

    public init() {
        LiveViewController.contentPresentation = .aspectFitMaximum
        
        super.init(nibName: nil, bundle: nil)

        classesToRegister = [SceneProxy.self, AudioProxy.self, AccessibilityProxy.self]

        let liveViewScene = LiveViewScene(size: Scene.sceneSize)
        let learningTrailsButton = LearningTrailsBarButton()
        
        lifeCycleDelegates = [audioController, liveViewScene, learningTrailsButton]
        contentView = liveViewScene.skView
        
        let audioButton = AudioBarButton()
        
        audioButton.toggleBackgroundAudioOnly = true
        
        addBarButton(audioButton)
        addBarButton(learningTrailsButton)
    }

    required init?(coder: NSCoder) {
        fatalError("SonicLiveViewController.init?(coder) not implemented.")
    }
}
